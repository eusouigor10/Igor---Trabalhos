/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package igorigor.trabalhofisicaex08cap05;

/**
 *
 * @author The Jarbas
 */
public class TrabalhoFisicaEx08Cap05 {
    
    double massa;

    public TrabalhoFisicaEx08Cap05(double massa) {
        this.massa = massa;
    }
    
    
    
}
